<?php

namespace App\Models\Mall;

use Illuminate\Database\Eloquent\Model;

class MallStatus extends Model
{
    //
}
