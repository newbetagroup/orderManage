<?php

namespace App\Models\Mall;

use Illuminate\Database\Eloquent\Model;

class MallMall extends Model
{
    //
}
