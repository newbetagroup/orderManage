<?php

namespace App\Models\Domain;

use Illuminate\Database\Eloquent\Model;

class DomainHost extends Model
{
    //
}
