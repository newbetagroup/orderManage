<?php

namespace App\Models\Domain;

use Illuminate\Database\Eloquent\Model;

class DomainWebsiteStatus extends Model
{
    //
}
