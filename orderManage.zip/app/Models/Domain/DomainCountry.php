<?php

namespace App\Models\Domain;

use Illuminate\Database\Eloquent\Model;

class DomainCountry extends Model
{
    //
}
