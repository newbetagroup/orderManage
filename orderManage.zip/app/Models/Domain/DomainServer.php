<?php

namespace App\Models\Domain;

use Illuminate\Database\Eloquent\Model;

class DomainServer extends Model
{
    //
}
