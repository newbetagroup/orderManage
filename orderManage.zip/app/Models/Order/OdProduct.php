<?php

namespace App\Models\Order;

use Illuminate\Database\Eloquent\Model;

class OdProduct extends Model
{
    protected $guarded = ['id'];
}
