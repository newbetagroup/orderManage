<?php

namespace App\Models\Order;

use Illuminate\Database\Eloquent\Model;

class OdStatus extends Model
{
    //
}
