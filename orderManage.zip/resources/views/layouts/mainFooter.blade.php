  <footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
      Designed by NewBeta
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2016 <a href="#">NewBeta</a>.</strong> All rights reserved.
  </footer>