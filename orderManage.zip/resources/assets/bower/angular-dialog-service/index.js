require('./dist/dialogs.js');
require('./dist/dialogs-default-translations.js');
require('./dist/dialogs.css');
module.exports = 'dialogs.main';
