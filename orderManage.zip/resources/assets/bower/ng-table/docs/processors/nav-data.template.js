ngTableDoc
    .constant('{$ doc.name $}', {$ doc.items | json $});
